"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export interface Product {
  product_id: number
  category: string
  type: string
  variety: string
  price: number
  quantity: number
  expiry_date: string
}

export interface BillItem {
  product: Product
  sellQuantity: number
  total: number
}

export interface Bill {
  billNo: number
  date: string
  items: BillItem[]
  grandTotal: number
}

interface ProductsContextType {
  products: Product[]
  addProduct: (product: Product) => void
  sellProduct: (productId: number, quantity: number) => boolean
  outOfStockProducts: Product[]
  lowStockProducts: Product[]
  expiringSoonProducts: Product[]
  expiredProducts: Product[]
  bills: Bill[]
  addBill: (bill: Bill) => void
}

const ProductsContext = createContext<ProductsContextType | null>(null)

const LOW_STOCK_THRESHOLD = 10

export function ProductsProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>([])

  const addProduct = (product: Product) => {
    setProducts(prev => [...prev, product])
  }

  const outOfStockProducts = products.filter(p => p.quantity === 0)
  const lowStockProducts = products.filter(p => p.quantity > 0 && p.quantity <= LOW_STOCK_THRESHOLD)
  
  // Check for expiring products (within 1 month)
  const today = new Date()
  const oneMonthFromNow = new Date()
  oneMonthFromNow.setMonth(oneMonthFromNow.getMonth() + 1)
  
  const expiringSoonProducts = products.filter(p => {
    const expiryDate = new Date(p.expiry_date)
    return expiryDate > today && expiryDate <= oneMonthFromNow
  })
  
  const expiredProducts = products.filter(p => {
    const expiryDate = new Date(p.expiry_date)
    return expiryDate <= today
  })

  return (
    <ProductsContext.Provider value={{ products, addProduct, outOfStockProducts, lowStockProducts, expiringSoonProducts, expiredProducts }}>
      {children}
    </ProductsContext.Provider>
  )
}

export function useProducts() {
  const context = useContext(ProductsContext)
  if (!context) {
    throw new Error("useProducts must be used within ProductsProvider")
  }
  return context
}
