"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useProducts } from "@/lib/products-context"
import Link from "next/link"

export default function ProductsPage() {
  const { isLoggedIn } = useAuth()
  const { products } = useProducts()
  const router = useRouter()

  useEffect(() => {
    if (!isLoggedIn) {
      router.push("/")
    }
  }, [isLoggedIn, router])

  if (!isLoggedIn) {
    return null
  }

  return (
    <div style={{
      minHeight: "100vh",
      backgroundColor: "#f0f4f8",
      fontFamily: "Arial, sans-serif",
      padding: "40px"
    }}>
      <div style={{ 
        maxWidth: "1000px", 
        margin: "0 auto" 
      }}>
        <div style={{ 
          display: "flex", 
          justifyContent: "space-between", 
          alignItems: "center",
          marginBottom: "30px"
        }}>
          <Link 
            href="/dashboard"
            style={{
              color: "#2c3e50",
              textDecoration: "none",
              fontSize: "16px"
            }}
          >
            &larr; Back to Dashboard
          </Link>
          <Link 
            href="/add-product"
            style={{
              backgroundColor: "#27ae60",
              color: "#fff",
              padding: "10px 20px",
              borderRadius: "6px",
              textDecoration: "none",
              fontSize: "14px",
              fontWeight: "bold"
            }}
          >
            + Add Product
          </Link>
        </div>
        
        <h1 style={{
          textAlign: "center",
          marginBottom: "30px",
          color: "#2c3e50"
        }}>
          Product List
        </h1>
        
        {products.length === 0 ? (
          <div style={{
            textAlign: "center",
            padding: "60px 20px",
            backgroundColor: "#fff",
            borderRadius: "12px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.1)"
          }}>
            <p style={{ fontSize: "18px", color: "#7f8c8d", marginBottom: "20px" }}>
              No products added yet.
            </p>
            <Link 
              href="/add-product"
              style={{
                backgroundColor: "#3498db",
                color: "#fff",
                padding: "12px 24px",
                borderRadius: "6px",
                textDecoration: "none",
                fontSize: "16px"
              }}
            >
              Add Your First Product
            </Link>
          </div>
        ) : (
          <div style={{
            backgroundColor: "#fff",
            borderRadius: "12px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
            overflow: "hidden"
          }}>
            <table style={{
              width: "100%",
              borderCollapse: "collapse"
            }}>
              <thead>
                <tr style={{ backgroundColor: "#2c3e50", color: "#fff" }}>
                  <th style={{ padding: "15px", textAlign: "left" }}>ID</th>
                  <th style={{ padding: "15px", textAlign: "left" }}>Category</th>
                  <th style={{ padding: "15px", textAlign: "left" }}>Type</th>
                  <th style={{ padding: "15px", textAlign: "left" }}>Variety</th>
                  <th style={{ padding: "15px", textAlign: "right" }}>Price</th>
                  <th style={{ padding: "15px", textAlign: "right" }}>Qty</th>
                  <th style={{ padding: "15px", textAlign: "center" }}>Stock Status</th>
                  <th style={{ padding: "15px", textAlign: "left" }}>Expiry</th>
                  <th style={{ padding: "15px", textAlign: "center" }}>Expiry Status</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product, index) => (
                  <tr 
                    key={product.product_id}
                    style={{ 
                      backgroundColor: product.quantity === 0 
                        ? "#fee2e2" 
                        : product.quantity <= 10 
                          ? "#fef3c7" 
                          : index % 2 === 0 ? "#f9f9f9" : "#fff",
                      borderBottom: "1px solid #eee"
                    }}
                  >
                    <td style={{ padding: "12px 15px" }}>{product.product_id}</td>
                    <td style={{ padding: "12px 15px" }}>{product.category}</td>
                    <td style={{ padding: "12px 15px" }}>{product.type}</td>
                    <td style={{ padding: "12px 15px" }}>{product.variety}</td>
                    <td style={{ padding: "12px 15px", textAlign: "right" }}>
                      Rs. {product.price.toFixed(2)}
                    </td>
                    <td style={{ padding: "12px 15px", textAlign: "right" }}>
                      {product.quantity}
                    </td>
                    <td style={{ padding: "12px 15px", textAlign: "center" }}>
                      {product.quantity === 0 ? (
                        <span style={{
                          backgroundColor: "#dc2626",
                          color: "#fff",
                          padding: "4px 10px",
                          borderRadius: "4px",
                          fontSize: "12px",
                          fontWeight: "bold"
                        }}>
                          OUT OF STOCK
                        </span>
                      ) : product.quantity <= 10 ? (
                        <span style={{
                          backgroundColor: "#f59e0b",
                          color: "#fff",
                          padding: "4px 10px",
                          borderRadius: "4px",
                          fontSize: "12px",
                          fontWeight: "bold"
                        }}>
                          LOW STOCK
                        </span>
                      ) : (
                        <span style={{
                          backgroundColor: "#22c55e",
                          color: "#fff",
                          padding: "4px 10px",
                          borderRadius: "4px",
                          fontSize: "12px",
                          fontWeight: "bold"
                        }}>
                          IN STOCK
                        </span>
                      )}
                    </td>
                    <td style={{ padding: "12px 15px" }}>{product.expiry_date}</td>
                    <td style={{ padding: "12px 15px", textAlign: "center" }}>
                      {(() => {
                        const today = new Date()
                        const expiryDate = new Date(product.expiry_date)
                        const oneMonthFromNow = new Date()
                        oneMonthFromNow.setMonth(oneMonthFromNow.getMonth() + 1)
                        
                        if (expiryDate <= today) {
                          return (
                            <span style={{
                              backgroundColor: "#b91c1c",
                              color: "#fff",
                              padding: "4px 10px",
                              borderRadius: "4px",
                              fontSize: "12px",
                              fontWeight: "bold"
                            }}>
                              EXPIRED
                            </span>
                          )
                        } else if (expiryDate <= oneMonthFromNow) {
                          return (
                            <span style={{
                              backgroundColor: "#3b82f6",
                              color: "#fff",
                              padding: "4px 10px",
                              borderRadius: "4px",
                              fontSize: "12px",
                              fontWeight: "bold"
                            }}>
                              EXPIRING SOON
                            </span>
                          )
                        } else {
                          return (
                            <span style={{
                              backgroundColor: "#10b981",
                              color: "#fff",
                              padding: "4px 10px",
                              borderRadius: "4px",
                              fontSize: "12px",
                              fontWeight: "bold"
                            }}>
                              OK
                            </span>
                          )
                        }
                      })()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
