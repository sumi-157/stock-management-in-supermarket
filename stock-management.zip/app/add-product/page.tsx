"use client"

import React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useProducts } from "@/lib/products-context"
import Link from "next/link"

// Category -> Type -> Variety data structure
const productData: Record<string, Record<string, string[]>> = {
  Rice: {
    "Basmati Rice": ["Traditional Basmati", "1121 Basmati", "Pusa Basmati"],
    "Non-Basmati Rice": ["Sona Masoori", "Ponni Rice", "Kolam Rice"],
    "Brown Rice": ["Long Grain Brown", "Short Grain Brown", "Red Rice"],
  },
  Oil: {
    "Cooking Oil": ["Sunflower Oil", "Groundnut Oil", "Mustard Oil"],
    "Refined Oil": ["Soybean Oil", "Rice Bran Oil", "Canola Oil"],
    "Cold Pressed": ["Coconut Oil", "Sesame Oil", "Olive Oil"],
  },
  Spices: {
    "Whole Spices": ["Cumin Seeds", "Coriander Seeds", "Black Pepper"],
    "Ground Spices": ["Turmeric Powder", "Red Chilli Powder", "Garam Masala"],
    "Exotic Spices": ["Saffron", "Star Anise", "Cinnamon Sticks"],
  },
  Masalas: {
    "Kitchen Masala": ["Sambar Powder", "Rasam Powder", "Biryani Masala"],
    "Curry Masala": ["Chicken Masala", "Fish Masala", "Paneer Masala"],
    "Special Masala": ["Pav Bhaji Masala", "Chaat Masala", "Tandoori Masala"],
  },
  Noodles: {
    "Instant Noodles": ["Maggi", "Yippee", "Top Ramen"],
    "Hakka Noodles": ["Veg Hakka", "Egg Hakka", "Schezwan Noodles"],
    "Rice Noodles": ["Vermicelli", "Rice Sticks", "Flat Rice Noodles"],
  },
  Millet: {
    "Common Millets": ["Foxtail Millet", "Finger Millet", "Pearl Millet"],
    "Minor Millets": ["Barnyard Millet", "Little Millet", "Kodo Millet"],
    "Millet Products": ["Millet Flour", "Millet Flakes", "Millet Rava"],
  },
  Dal: {
    "Whole Dal": ["Chana Dal", "Urad Dal", "Moong Dal"],
    "Split Dal": ["Toor Dal", "Masoor Dal", "Yellow Moong Dal"],
    "Special Dal": ["Rajma", "Kabuli Chana", "Black Eyed Peas"],
  },
}

const categories = Object.keys(productData)

export default function AddProductPage() {
  const { isLoggedIn } = useAuth()
  const { addProduct, outOfStockProducts, lowStockProducts, expiringSoonProducts, expiredProducts } = useProducts()
  const router = useRouter()
  
  const [productId, setProductId] = useState("")
  const [category, setCategory] = useState("")
  const [type, setType] = useState("")
  const [variety, setVariety] = useState("")
  const [price, setPrice] = useState("")
  const [quantity, setQuantity] = useState("")
  const [expiryDate, setExpiryDate] = useState("")
  const [message, setMessage] = useState("")
  const [showAlerts, setShowAlerts] = useState(false)

  const types = category ? Object.keys(productData[category] || {}) : []
  const varieties = category && type ? productData[category]?.[type] || [] : []

  // Reset dependent dropdowns when parent changes
  useEffect(() => {
    setType("")
    setVariety("")
  }, [category])

  useEffect(() => {
    setVariety("")
  }, [type])

  useEffect(() => {
    if (!isLoggedIn) {
      router.push("/")
    }
  }, [isLoggedIn, router])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const product = {
      product_id: parseInt(productId),
      category,
      type,
      variety,
      price: parseFloat(price),
      quantity: parseInt(quantity),
      expiry_date: expiryDate
    }
    
    addProduct(product)
    setMessage("New product inserted successfully!")
    
    // Reset form
    setProductId("")
    setCategory("")
    setType("")
    setVariety("")
    setPrice("")
    setQuantity("")
    setExpiryDate("")
  }

  const totalAlerts = outOfStockProducts.length + lowStockProducts.length + expiringSoonProducts.length + expiredProducts.length

  if (!isLoggedIn) {
    return null
  }

  return (
    <div style={{
      minHeight: "100vh",
      backgroundColor: "#f5f5f5",
      fontFamily: "Arial, sans-serif",
      padding: "40px 20px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center"
    }}>
      <h1 style={{
        textAlign: "center",
        marginBottom: "30px",
        color: "#000",
        fontSize: "24px",
        fontWeight: "bold"
      }}>
        Product information
      </h1>
      
      <form onSubmit={handleSubmit} style={{ width: "100%", maxWidth: "350px" }}>
        <div style={{ marginBottom: "15px", display: "flex", alignItems: "center" }}>
          <label style={{ 
            width: "100px", 
            textAlign: "right", 
            marginRight: "10px",
            fontSize: "14px"
          }}>
            Product_id:
          </label>
          <input
            type="text"
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
            required
            style={{
              flex: 1,
              padding: "6px 8px",
              fontSize: "14px",
              border: "1px solid #999",
              backgroundColor: "#fff"
            }}
          />
        </div>
        
        <div style={{ marginBottom: "15px", display: "flex", alignItems: "center" }}>
          <label style={{ 
            width: "100px", 
            textAlign: "right", 
            marginRight: "10px",
            fontSize: "14px"
          }}>
            Category:
          </label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            required
            style={{
              flex: 1,
              padding: "6px 8px",
              fontSize: "14px",
              border: "1px solid #999",
              backgroundColor: "#fff"
            }}
          >
            <option value="">-- Select Category --</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
        
        <div style={{ marginBottom: "15px", display: "flex", alignItems: "center" }}>
          <label style={{ 
            width: "100px", 
            textAlign: "right", 
            marginRight: "10px",
            fontSize: "14px"
          }}>
            Type:
          </label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            required
            disabled={!category}
            style={{
              flex: 1,
              padding: "6px 8px",
              fontSize: "14px",
              border: "1px solid #999",
              backgroundColor: category ? "#fff" : "#eee"
            }}
          >
            <option value="">-- Select Type --</option>
            {types.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </div>
        
        <div style={{ marginBottom: "15px", display: "flex", alignItems: "center" }}>
          <label style={{ 
            width: "100px", 
            textAlign: "right", 
            marginRight: "10px",
            fontSize: "14px"
          }}>
            Variety:
          </label>
          <select
            value={variety}
            onChange={(e) => setVariety(e.target.value)}
            required
            disabled={!type}
            style={{
              flex: 1,
              padding: "6px 8px",
              fontSize: "14px",
              border: "1px solid #999",
              backgroundColor: type ? "#fff" : "#eee"
            }}
          >
            <option value="">-- Select Variety --</option>
            {varieties.map((v) => (
              <option key={v} value={v}>{v}</option>
            ))}
          </select>
        </div>
        
        <div style={{ marginBottom: "15px", display: "flex", alignItems: "center" }}>
          <label style={{ 
            width: "100px", 
            textAlign: "right", 
            marginRight: "10px",
            fontSize: "14px"
          }}>
            Price:
          </label>
          <input
            type="text"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
            style={{
              flex: 1,
              padding: "6px 8px",
              fontSize: "14px",
              border: "1px solid #999",
              backgroundColor: "#fff"
            }}
          />
        </div>
        
        <div style={{ marginBottom: "15px", display: "flex", alignItems: "center" }}>
          <label style={{ 
            width: "100px", 
            textAlign: "right", 
            marginRight: "10px",
            fontSize: "14px"
          }}>
            Quantity:
          </label>
          <input
            type="text"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            required
            style={{
              flex: 1,
              padding: "6px 8px",
              fontSize: "14px",
              border: "1px solid #999",
              backgroundColor: "#fff"
            }}
          />
        </div>
        
        <div style={{ marginBottom: "20px", display: "flex", alignItems: "center" }}>
          <label style={{ 
            width: "100px", 
            textAlign: "right", 
            marginRight: "10px",
            fontSize: "14px"
          }}>
            Expiry Date:
          </label>
          <input
            type="date"
            value={expiryDate}
            onChange={(e) => setExpiryDate(e.target.value)}
            required
            style={{
              flex: 1,
              padding: "6px 8px",
              fontSize: "14px",
              border: "1px solid #999",
              backgroundColor: "#fff"
            }}
          />
        </div>
        
        {message && (
          <p style={{
            color: "#27ae60",
            textAlign: "center",
            marginBottom: "15px",
            fontWeight: "bold"
          }}>
            {message}
          </p>
        )}
        
        <div style={{ textAlign: "center", display: "flex", gap: "10px", justifyContent: "center", flexWrap: "wrap" }}>
          <button
            type="submit"
            style={{
              padding: "8px 30px",
              backgroundColor: "#e0e0e0",
              color: "#000",
              border: "1px solid #999",
              fontSize: "14px",
              cursor: "pointer"
            }}
          >
            Save
          </button>
          <Link
            href="/dashboard"
            style={{
              padding: "8px 20px",
              backgroundColor: "#4a90d9",
              color: "#fff",
              border: "1px solid #3a7bc8",
              fontSize: "14px",
              cursor: "pointer",
              textDecoration: "none",
              display: "inline-block"
            }}
          >
            Dashboard
          </Link>
          <button
            type="button"
            onClick={() => setShowAlerts(!showAlerts)}
            style={{
              padding: "8px 20px",
              backgroundColor: totalAlerts > 0 ? "#e74c3c" : "#95a5a6",
              color: "#fff",
              border: "none",
              fontSize: "14px",
              cursor: "pointer",
              position: "relative"
            }}
          >
            Alerts
            {totalAlerts > 0 && (
              <span style={{
                position: "absolute",
                top: "-8px",
                right: "-8px",
                backgroundColor: "#c0392b",
                color: "#fff",
                borderRadius: "50%",
                width: "20px",
                height: "20px",
                fontSize: "12px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
              }}>
                {totalAlerts}
              </span>
            )}
          </button>
        </div>
      </form>

      {/* Alerts Panel */}
      {showAlerts && (
        <div style={{
          marginTop: "30px",
          width: "100%",
          maxWidth: "500px"
        }}>
          <h3 style={{ textAlign: "center", marginBottom: "15px" }}>Stock & Expiry Alerts</h3>
          
          {totalAlerts === 0 ? (
            <p style={{ textAlign: "center", color: "#27ae60" }}>No alerts at this time.</p>
          ) : (
            <>
              {outOfStockProducts.length > 0 && (
                <div style={{
                  backgroundColor: "#fee2e2",
                  border: "2px solid #dc2626",
                  borderRadius: "8px",
                  padding: "12px 16px",
                  marginBottom: "10px"
                }}>
                  <h4 style={{ margin: "0 0 8px 0", color: "#991b1b" }}>OUT OF STOCK</h4>
                  <ul style={{ margin: 0, paddingLeft: "20px", color: "#991b1b", fontSize: "14px" }}>
                    {outOfStockProducts.map((p) => (
                      <li key={p.product_id}>{p.category} - {p.type} ({p.variety})</li>
                    ))}
                  </ul>
                </div>
              )}

              {lowStockProducts.length > 0 && (
                <div style={{
                  backgroundColor: "#fef3c7",
                  border: "2px solid #f59e0b",
                  borderRadius: "8px",
                  padding: "12px 16px",
                  marginBottom: "10px"
                }}>
                  <h4 style={{ margin: "0 0 8px 0", color: "#92400e" }}>LOW STOCK</h4>
                  <ul style={{ margin: 0, paddingLeft: "20px", color: "#92400e", fontSize: "14px" }}>
                    {lowStockProducts.map((p) => (
                      <li key={p.product_id}>{p.category} - {p.type} ({p.variety}) - {p.quantity} left</li>
                    ))}
                  </ul>
                </div>
              )}

              {expiredProducts.length > 0 && (
                <div style={{
                  backgroundColor: "#fecaca",
                  border: "2px solid #b91c1c",
                  borderRadius: "8px",
                  padding: "12px 16px",
                  marginBottom: "10px"
                }}>
                  <h4 style={{ margin: "0 0 8px 0", color: "#7f1d1d" }}>EXPIRED</h4>
                  <ul style={{ margin: 0, paddingLeft: "20px", color: "#7f1d1d", fontSize: "14px" }}>
                    {expiredProducts.map((p) => (
                      <li key={p.product_id}>{p.category} - {p.type} ({p.variety}) - Expired: {p.expiry_date}</li>
                    ))}
                  </ul>
                </div>
              )}

              {expiringSoonProducts.length > 0 && (
                <div style={{
                  backgroundColor: "#dbeafe",
                  border: "2px solid #3b82f6",
                  borderRadius: "8px",
                  padding: "12px 16px"
                }}>
                  <h4 style={{ margin: "0 0 8px 0", color: "#1e40af" }}>EXPIRING SOON (1 Month)</h4>
                  <ul style={{ margin: 0, paddingLeft: "20px", color: "#1e40af", fontSize: "14px" }}>
                    {expiringSoonProducts.map((p) => (
                      <li key={p.product_id}>{p.category} - {p.type} ({p.variety}) - Expires: {p.expiry_date}</li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  )
}
