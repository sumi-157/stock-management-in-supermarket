"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useProducts } from "@/lib/products-context"
import Link from "next/link"

const categories = [
  { id: "rice", name: "Rice", color: "#f5e6d3", image: "/images/rice.jpeg" },
  { id: "oil", name: "Oil", color: "#fff3cd", image: "/images/oil.jpg" },
  { id: "spices", name: "Spices", color: "#f8d7da", image: "/images/bgspecies.jpeg" },
  { id: "masalas", name: "Masalas", color: "#ffe5d9", image: "/images/masala.jpg" },
  { id: "noodles", name: "Noodles", color: "#fff1e6", image: "/images/noodles.jpg" },
  { id: "millet", name: "Millet", color: "#e8f5e9", image: "/images/millet.jpg" },
  { id: "dal", name: "Dal", color: "#fef3c7", image: "/images/dal.jpg" },
]

export default function DashboardPage() {
  const { isLoggedIn, logout } = useAuth()
  const { outOfStockProducts, lowStockProducts, expiringSoonProducts, expiredProducts } = useProducts()
  const router = useRouter()

  useEffect(() => {
    if (!isLoggedIn) {
      router.push("/")
    }
  }, [isLoggedIn, router])

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  if (!isLoggedIn) {
    return null
  }

  return (
    <div style={{
      minHeight: "100vh",
      backgroundColor: "#f0f4f8",
      fontFamily: "Arial, sans-serif"
    }}>
      {/* Header */}
      <header style={{
        backgroundColor: "#2c3e50",
        color: "#fff",
        padding: "20px 40px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }}>
        <h1 style={{ margin: 0, fontSize: "24px" }}>STOCK MANAGEMENT</h1>
        <div style={{ display: "flex", gap: "15px" }}>
          <Link 
            href="/add-product"
            style={{
              backgroundColor: "#27ae60",
              color: "#fff",
              padding: "10px 20px",
              borderRadius: "6px",
              textDecoration: "none",
              fontSize: "14px",
              fontWeight: "bold"
            }}
          >
            + Add Product
          </Link>
          <Link 
            href="/products"
            style={{
              backgroundColor: "#3498db",
              color: "#fff",
              padding: "10px 20px",
              borderRadius: "6px",
              textDecoration: "none",
              fontSize: "14px",
              fontWeight: "bold"
            }}
          >
            View Products
          </Link>
          <button
            onClick={handleLogout}
            style={{
              backgroundColor: "#e74c3c",
              color: "#fff",
              padding: "10px 20px",
              border: "none",
              borderRadius: "6px",
              fontSize: "14px",
              fontWeight: "bold",
              cursor: "pointer"
            }}
          >
            Logout
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main style={{ padding: "40px" }}>
        {/* Stock and Expiry Alerts */}
        {(outOfStockProducts.length > 0 || lowStockProducts.length > 0 || expiredProducts.length > 0 || expiringSoonProducts.length > 0) && (
          <div style={{
            maxWidth: "1200px",
            margin: "0 auto 30px auto"
          }}>
            {outOfStockProducts.length > 0 && (
              <div style={{
                backgroundColor: "#fee2e2",
                border: "2px solid #dc2626",
                borderRadius: "8px",
                padding: "16px 20px",
                marginBottom: "15px",
                display: "flex",
                alignItems: "flex-start",
                gap: "12px"
              }}>
                <span style={{ fontSize: "24px" }}>&#9888;</span>
                <div>
                  <h3 style={{ 
                    margin: "0 0 8px 0", 
                    color: "#991b1b",
                    fontSize: "18px"
                  }}>
                    OUT OF STOCK ALERT!
                  </h3>
                  <p style={{ margin: "0 0 10px 0", color: "#b91c1c" }}>
                    The following products are out of stock:
                  </p>
                  <ul style={{ 
                    margin: 0, 
                    paddingLeft: "20px",
                    color: "#991b1b"
                  }}>
                    {outOfStockProducts.map((p) => (
                      <li key={p.product_id} style={{ marginBottom: "4px" }}>
                        <strong>{p.category}</strong> - {p.type} ({p.variety})
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {lowStockProducts.length > 0 && (
              <div style={{
                backgroundColor: "#fef3c7",
                border: "2px solid #f59e0b",
                borderRadius: "8px",
                padding: "16px 20px",
                marginBottom: "15px",
                display: "flex",
                alignItems: "flex-start",
                gap: "12px"
              }}>
                <span style={{ fontSize: "24px" }}>&#9888;</span>
                <div>
                  <h3 style={{ 
                    margin: "0 0 8px 0", 
                    color: "#92400e",
                    fontSize: "18px"
                  }}>
                    LOW STOCK WARNING
                  </h3>
                  <p style={{ margin: "0 0 10px 0", color: "#b45309" }}>
                    The following products have low stock (10 or less):
                  </p>
                  <ul style={{ 
                    margin: 0, 
                    paddingLeft: "20px",
                    color: "#92400e"
                  }}>
                    {lowStockProducts.map((p) => (
                      <li key={p.product_id} style={{ marginBottom: "4px" }}>
                        <strong>{p.category}</strong> - {p.type} ({p.variety}) - <span style={{ fontWeight: "bold" }}>{p.quantity} left</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {expiredProducts.length > 0 && (
              <div style={{
                backgroundColor: "#fecaca",
                border: "2px solid #b91c1c",
                borderRadius: "8px",
                padding: "16px 20px",
                marginBottom: "15px",
                display: "flex",
                alignItems: "flex-start",
                gap: "12px"
              }}>
                <span style={{ fontSize: "24px" }}>&#128683;</span>
                <div>
                  <h3 style={{ 
                    margin: "0 0 8px 0", 
                    color: "#7f1d1d",
                    fontSize: "18px"
                  }}>
                    EXPIRED PRODUCTS!
                  </h3>
                  <p style={{ margin: "0 0 10px 0", color: "#991b1b" }}>
                    The following products have expired and should be removed:
                  </p>
                  <ul style={{ 
                    margin: 0, 
                    paddingLeft: "20px",
                    color: "#7f1d1d"
                  }}>
                    {expiredProducts.map((p) => (
                      <li key={p.product_id} style={{ marginBottom: "4px" }}>
                        <strong>{p.category}</strong> - {p.type} ({p.variety}) - <span style={{ fontWeight: "bold", color: "#b91c1c" }}>Expired: {p.expiry_date}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {expiringSoonProducts.length > 0 && (
              <div style={{
                backgroundColor: "#dbeafe",
                border: "2px solid #3b82f6",
                borderRadius: "8px",
                padding: "16px 20px",
                display: "flex",
                alignItems: "flex-start",
                gap: "12px"
              }}>
                <span style={{ fontSize: "24px" }}>&#128197;</span>
                <div>
                  <h3 style={{ 
                    margin: "0 0 8px 0", 
                    color: "#1e40af",
                    fontSize: "18px"
                  }}>
                    EXPIRING SOON (Within 1 Month)
                  </h3>
                  <p style={{ margin: "0 0 10px 0", color: "#1d4ed8" }}>
                    The following products will expire within the next month:
                  </p>
                  <ul style={{ 
                    margin: 0, 
                    paddingLeft: "20px",
                    color: "#1e40af"
                  }}>
                    {expiringSoonProducts.map((p) => (
                      <li key={p.product_id} style={{ marginBottom: "4px" }}>
                        <strong>{p.category}</strong> - {p.type} ({p.variety}) - <span style={{ fontWeight: "bold" }}>Expires: {p.expiry_date}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}

        <h2 style={{
          textAlign: "center",
          marginBottom: "40px",
          color: "#2c3e50",
          fontSize: "28px"
        }}>
          Product Categories
        </h2>
        
        <div style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "25px",
          justifyContent: "center",
          maxWidth: "1200px",
          margin: "0 auto"
        }}>
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/category/${category.id}`}
              style={{
                backgroundColor: category.color,
                padding: "20px",
                borderRadius: "12px",
                textDecoration: "none",
                boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
                transition: "transform 0.2s, box-shadow 0.2s",
                width: "180px",
                textAlign: "center"
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = "translateY(-5px)"
                e.currentTarget.style.boxShadow = "0 8px 20px rgba(0,0,0,0.15)"
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = "translateY(0)"
                e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.1)"
              }}
            >
              <img
                src={category.image || "/placeholder.svg"}
                alt={category.name}
                style={{
                  width: "120px",
                  height: "120px",
                  objectFit: "cover",
                  borderRadius: "8px",
                  marginBottom: "12px"
                }}
              />
              <h3 style={{
                margin: 0,
                color: "#2c3e50",
                fontSize: "18px"
              }}>
                {category.name}
              </h3>
              <p style={{
                marginTop: "8px",
                padding: "6px 12px",
                backgroundColor: "#fff",
                borderRadius: "4px",
                color: "#666",
                fontSize: "14px",
                display: "inline-block"
              }}>
                Pick
              </p>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
