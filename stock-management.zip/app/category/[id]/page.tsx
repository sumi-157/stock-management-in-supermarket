"use client"

import { useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import Link from "next/link"

const categoryInfo: Record<string, { title: string; types: { name: string; items: string[] }[] }> = {
  rice: {
    title: "Varieties of Rice",
    types: [
      { name: "Rice", items: ["Ponni Rice", "Boiled Rice", "Sona Masoori"] },
      { name: "Basmati Rice", items: ["India Gate", "Daawat", "Fortune"] }
    ]
  },
  oil: {
    title: "Varieties of Oil",
    types: [
      { name: "Cooking Oil", items: ["Coconut Oil", "Groundnut Oil", "Sunflower Oil"] },
      { name: "Cosmetic Oil", items: ["Almond Oil", "Vitamin E Oil", "Castor Oil"] }
    ]
  },
  masalas: {
    title: "Varieties of Masalas",
    types: [
      { name: "Blended Masala", items: ["Garam Masala", "Sambar Powder", "Rasam Powder"] },
      { name: "Single Spice", items: ["Turmeric", "Red Chilli Powder", "Coriander Powder"] }
    ]
  },
  noodles: {
    title: "Varieties of Noodles",
    types: [
      { name: "Instant Noodles", items: ["Maggi", "Top Ramen", "Yippee"] },
      { name: "Dry Noodles", items: ["Hakka Noodles", "Rice Noodles", "Vermicelli"] }
    ]
  },
  millet: {
    title: "Varieties of Millet",
    types: [
      { name: "Common Millets", items: ["Ragi", "Jowar", "Bajra"] },
      { name: "Minor Millets", items: ["Foxtail", "Little Millet", "Kodo Millet"] }
    ]
  },
  dal: {
    title: "Varieties of Dal",
    types: [
      { name: "Whole Dal", items: ["Chana Dal", "Urad Dal", "Moong Dal"] },
      { name: "Split Dal", items: ["Toor Dal", "Masoor Dal", "Yellow Moong"] }
    ]
  }
}

const categoryColors: Record<string, string> = {
  rice: "#f5e6d3",
  oil: "#fff3cd",
  masalas: "#ffe5d9",
  noodles: "#fff1e6",
  millet: "#e8f5e9",
  dal: "#fef3c7"
}

export default function CategoryPage() {
  const { isLoggedIn } = useAuth()
  const router = useRouter()
  const params = useParams()
  const categoryId = params.id as string

  useEffect(() => {
    if (!isLoggedIn) {
      router.push("/")
    }
  }, [isLoggedIn, router])

  // Redirect spices to dedicated page
  useEffect(() => {
    if (categoryId === "spices") {
      router.push("/category/spices")
    }
  }, [categoryId, router])

  if (!isLoggedIn || categoryId === "spices") {
    return null
  }

  const category = categoryInfo[categoryId]
  const bgColor = categoryColors[categoryId] || "#f0f4f8"

  if (!category) {
    return (
      <div style={{ padding: "40px", textAlign: "center" }}>
        <h1>Category not found</h1>
        <Link href="/dashboard" style={{ color: "#3498db" }}>Back to Dashboard</Link>
      </div>
    )
  }

  return (
    <div style={{
      minHeight: "100vh",
      padding: "24px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: bgColor,
      textAlign: "center"
    }}>
      <div style={{ marginBottom: "20px" }}>
        <Link 
          href="/dashboard"
          style={{
            color: "#2c3e50",
            textDecoration: "none",
            fontSize: "16px",
            padding: "8px 16px",
            backgroundColor: "rgba(255,255,255,0.7)",
            borderRadius: "6px"
          }}
        >
          &larr; Back to Dashboard
        </Link>
      </div>
      
      <h1 style={{
        backgroundColor: "#2c3e50",
        color: "white",
        padding: "15px 30px",
        borderRadius: "8px",
        display: "inline-block",
        marginBottom: "30px"
      }}>
        {category.title}
      </h1>

      <div style={{
        display: "flex",
        flexWrap: "wrap",
        gap: "20px",
        justifyContent: "center",
        maxWidth: "800px",
        margin: "0 auto"
      }}>
        {category.types.map((type) => (
          <div
            key={type.name}
            style={{
              backgroundColor: "#fff",
              padding: "20px",
              borderRadius: "12px",
              boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
              minWidth: "250px",
              textAlign: "left"
            }}
          >
            <h3 style={{
              margin: "0 0 15px",
              color: "#2c3e50",
              borderBottom: "2px solid #eee",
              paddingBottom: "10px"
            }}>
              {type.name}
            </h3>
            <ul style={{ margin: 0, paddingLeft: "20px" }}>
              {type.items.map((item) => (
                <li key={item} style={{ marginBottom: "8px", color: "#555" }}>
                  {item}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  )
}
