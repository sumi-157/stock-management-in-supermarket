"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import Link from "next/link"

const spicesData = {
  "Seed Spices": [
    { name: "Coriander", description: "Fragrant seeds for curry" },
    { name: "Pepper", description: "Black pepper seeds" }
  ],
  "Berries": [
    { name: "Chilli", description: "Red hot chillies" },
    { name: "Black Pepper", description: "Whole black peppercorns" }
  ],
  "Aromatic": [
    { name: "Clove", description: "Aromatic flower buds" },
    { name: "Cinnamon", description: "Sweet cinnamon sticks" }
  ]
}

export default function SpicesCategoryPage() {
  const { isLoggedIn } = useAuth()
  const router = useRouter()
  const [openMenu, setOpenMenu] = useState<string | null>(null)

  useEffect(() => {
    if (!isLoggedIn) {
      router.push("/")
    }
  }, [isLoggedIn, router])

  const toggleSubmenu = (menuId: string) => {
    setOpenMenu(openMenu === menuId ? null : menuId)
  }

  if (!isLoggedIn) {
    return null
  }

  return (
    <div style={{
      minHeight: "100vh",
      padding: "24px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#8B4513",
      backgroundImage: "url('/images/bgspecies.jpeg')",
      backgroundSize: "cover",
      backgroundPosition: "center",
      backgroundAttachment: "fixed",
      color: "black",
      textAlign: "center"
    }}>
      <div style={{ marginBottom: "20px" }}>
        <Link 
          href="/dashboard"
          style={{
            color: "#fff",
            textDecoration: "none",
            fontSize: "16px",
            padding: "8px 16px",
            backgroundColor: "rgba(0,0,0,0.3)",
            borderRadius: "6px"
          }}
        >
          &larr; Back to Dashboard
        </Link>
      </div>
      
      <h1 style={{
        backgroundColor: "#8B4513",
        color: "white",
        padding: "15px",
        borderRadius: "8px",
        maxWidth: "400px",
        margin: "0 auto 30px"
      }}>
        Varieties of Spices
      </h1>

      <div style={{
        display: "inline-block",
        textAlign: "left",
        marginTop: "30px",
        minWidth: "250px"
      }}>
        {Object.entries(spicesData).map(([category, items]) => (
          <div key={category} style={{ position: "relative", marginBottom: "10px" }}>
            <div
              onClick={() => toggleSubmenu(category)}
              style={{
                backgroundColor: "#fff",
                padding: "12px 20px",
                border: "1px solid #ccc",
                borderRadius: "6px",
                cursor: "pointer",
                fontSize: "18px",
                transition: "background 0.2s"
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = "#f5f5f5"}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = "#fff"}
            >
              {category}
              <span style={{ float: "right" }}>{openMenu === category ? "▼" : "▶"}</span>
            </div>
            
            {openMenu === category && (
              <div style={{
                backgroundColor: "#fff",
                border: "1px solid #ccc",
                borderRadius: "6px",
                padding: "10px",
                marginTop: "5px",
                minWidth: "180px"
              }}>
                {items.map((item) => (
                  <div
                    key={item.name}
                    style={{
                      padding: "8px 16px",
                      backgroundColor: "#f0f0f0",
                      marginBottom: "6px",
                      borderRadius: "6px",
                      fontSize: "16px",
                      cursor: "pointer"
                    }}
                    onMouseOver={(e) => e.currentTarget.style.backgroundColor = "#e0e0e0"}
                    onMouseOut={(e) => e.currentTarget.style.backgroundColor = "#f0f0f0"}
                  >
                    <strong>{item.name}</strong>
                    <p style={{ margin: "4px 0 0", fontSize: "12px", color: "#666" }}>
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
